import{_ as a,b as e,e as t,l as d}from"./index.74c2d35f.js";const i={},s={class:"gridContainer"},v=d(`<h3 data-v-050e0896>1.\u5BB9\u5668\u5C5E\u6027 grid-template-areas \u5C5E\u6027\u5728\u7F51\u683C\u5E03\u5C40\u4E2D\u89C4\u5B9A\u533A\u57DF</h3><p data-v-050e0896>\u4E00\u4E2A\u533A\u57DF\u7531\u5355\u4E2A\u6216\u591A\u4E2A\u5355\u5143\u683C\u7EC4\u6210\uFF0C\u7531\u81EA\u5DF1\u51B3\u5B9A\uFF08\u5177\u4F53\u4F7F\u7528\uFF0C\u9700\u8981\u5728\u9879\u76EE\u5C5E\u6027\u91CC\u8BBE\u7F6E\uFF09</p><pre data-v-050e0896>            grid-template-areas:&#39;a b c&#39;
                                &#39;d e f&#39;
                                &#39;g h i&#39;;
            grid-template-areas:&#39;a a a&#39;
                                &#39;b b b&#39;
                                &#39;c c c&#39;;
            grid-template-areas:&#39;a . c&#39;
                                &#39;d . f&#39;
                                &#39;g . i&#39;;
            \u533A\u57DF\u4E0D\u9700\u8981\u5229\u7528\uFF0C\u5219\u4F7F\u7528\u201C\u70B9\u201D\uFF08.\uFF09\u8868\u793A\uFF0C\u533A\u57DF\u7684\u547D\u540D\u4F1A\u5F71\u54CD\u5230\u7F51\u683C\u7EBF\u3002
            \u6BCF\u4E2A\u533A\u57DF\u7684\u8D77\u59CB\u7F51\u683C\u7EBF\uFF0C\u4F1A\u81EA\u52A8\u547D\u540D\u4E3A\u533A\u57DF\u540D-start\uFF0C\u7EC8\u6B62\u7F51\u683C\u7EBF\u81EA\u52A8\u547D\u540D\u4E3A\u533A\u57DF\u540D-end
        </pre><p data-v-050e0896>\u6CE8\u91CA\uFF1A</p><p data-v-050e0896>\u540D\u5B57\u76F8\u540C\u8868\u793A\u5728\u4E00\u4E2A\u533A\u57DF\uFF0C\u5B9A\u4F4D\u6216\u8005\u5199\u9879\u76EE\u5C5E\u6027\u7684\u65F6\u5019\u4F1A\u7528\u5230</p><p data-v-050e0896>1.grid-auto-flow:row(\u5148\u586B\u6EE1\u884C)</p><div class="container" data-v-050e0896><div class="item1" data-v-050e0896>1</div><div class="item2" data-v-050e0896>2</div><div class="item3" data-v-050e0896>3</div><div class="item4" data-v-050e0896>4</div><div class="item5" data-v-050e0896>5</div><div class="item6" data-v-050e0896>6</div><div class="item7" data-v-050e0896>7</div><div class="item8" data-v-050e0896>8</div><div class="item9" data-v-050e0896>9</div></div>`,7),c=[v];function n(r,_){return e(),t("div",s,c)}const o=a(i,[["render",n],["__scopeId","data-v-050e0896"]]);export{o as default};
