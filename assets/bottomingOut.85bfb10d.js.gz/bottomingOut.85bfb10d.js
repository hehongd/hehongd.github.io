import{_ as C,d as T,u as L,c as $,r as o,a as E,b as S,e as s,f as i,v as c,g as f,h as r,i as t,j as _,k as M,l as g,p as N,q as O}from"./index.bcb34b0e.js";const A=""+new URL("client.16c2a155.webp",import.meta.url).href,B=""+new URL("scrolling-offset.0936b9af.webp",import.meta.url).href;const a=d=>(N("data-v-524d7e28"),d=d(),O(),d),I=a(()=>s("h1",null,"\u5224\u65AD\u6EDA\u52A8\u6761\u662F\u5426\u6EDA\u52A8\u5230\u9875\u9762\u5E95\u90E8",-1)),R={class:"articleContanier"},V=_('<p data-v-524d7e28>scrollHeight\uFF1A\u6587\u6863\u5185\u5BB9\u5B9E\u9645\u9AD8\u5EA6\uFF0C\u5305\u62EC\u8D85\u8FC7\u5C4F\u5E55\u89C6\u53E3\u9AD8\u5EA6\u6EA2\u51FA\u7684\u90E8\u5206\u3002=\u5185\u5BB9\u7684\u5927\u5C0F+paddng</p><p data-v-524d7e28> scrollTop\uFF1A\u6EDA\u52A8\u6761\u8DDD\u5143\u7D20\uFF08\u4E0D\u4E00\u5B9A\u662F\u5C4F\u5E55\u6700\u9876\u7AEF\uFF09\u9876\u90E8\u6EDA\u52A8\u7684\u8DDD\u79BB\u3002</p><p data-v-524d7e28>clientHeight\uFF1A\u6D4F\u89C8\u5668\u7A97\u53E3\u53EF\u89C6\u8303\u56F4\u9AD8\u5EA6\uFF08\u5C31\u662F\u81EA\u5DF1\u80FD\u770B\u5230\u7684\u9AD8\u5EA6\uFF0C\u5982\u679C\u8FD9\u4E2A\u76D2\u5B50\u90FD\u5728\u53EF\u89C6\u533A\uFF0C\u5185\u5BB9\u5219\u662F\u76D2\u5B50\u7684\u9AD8\u5EA6\uFF09\u3002=\u5143\u7D20\u7684\u5927\u5C0F+padding\u3002</p><p data-v-524d7e28>offsetParent\uFF1A\u8DDD\u79BB\u8BE5\u5B50\u5143\u7D20\u6700\u8FD1\u7684\u8FDB\u884C\u8FC7\u5B9A\u4F4D\u7684\u7236\u5143\u7D20\uFF08position\uFF1Aabsolute relative fixed\uFF09\uFF0C\u5982\u679C\u5176\u7236\u5143\u7D20\u4E2D\u4E0D\u5B58\u5728\u5B9A\u4F4D\u5219offsetParent\u4E3A--body\u5143\u7D20\u3002=\u5143\u7D20\u7684\u5927\u5C0F+padding+border</p><div class="imgConter" data-v-524d7e28><img src="'+A+'" style="max-width:100%;height:auto;" data-v-524d7e28><div class="image-caption" data-v-524d7e28>\u5BA2\u6237\u533A\u5927\u5C0F</div></div><div class="imgConter" data-v-524d7e28><img src="'+B+'" style="max-width:100%;height:auto;" data-v-524d7e28><div class="image-caption" data-v-524d7e28>\u6EDA\u52A8\u504F\u79FB</div></div><h2 data-v-524d7e28>\u6EDA\u52A8\u6761\u662F\u5426\u6EDA\u5230\u5E95\u90E8\u7684\u5224\u65AD\u6761\u4EF6\u662F</h2>',7),j=a(()=>s("code",null,`
                    scrollHeight = scrollTop + clientHeight
                `,-1)),x=a(()=>s("p",null,"\u6240\u4EE5\u5728\u5B9E\u73B0\u65F6\u6211\u4EEC\u53EA\u8981\u83B7\u53D6\u8FD9\u4E09\u4E2A\u503C\u5C31\u53EF\u4EE5\u4E86\uFF0C\u800C\u8FD9\u4E09\u4E2A\u503Cjs\u90FD\u6709\u5BF9\u5E94\u7684api\u83B7\u53D6\uFF0C\u5206\u522B\u662F",-1)),U=a(()=>s("code",null,[t(`
                    `),s("span",{class:"keyword"},"let"),t(` scrollHeight = document.body.scrollHeight || document.documentElement.scrollHeight
                    `),s("span",{class:"keyword"},"let"),t(` scrollTop = document.body.scrollTop || document.documentElement.scrollTop
                    `),s("span",{class:"keyword"},"let"),t(` clientHeight = document.body.clientHeight || document.documentElement.clientHeight
                `)],-1)),P=a(()=>s("h2",null,"h5\u9875\u9762\u4E0A\u4E0B\u6ED1\u52A8\u7FFB\u9875",-1)),q=a(()=>s("p",null,"\u5224\u65AD\u6761\u4EF6\uFF1A1\uFF09\u89E6\u5E95\uFF0C\u89E6\u53D1\u7FFB\u9875\uFF0C2\uFF09\u7FFB\u9875\u7684\u65F6\u5019\uFF0C\u628A\u4E0A\u4E00\u9875\u5185\u5BB9\u4FDD\u5B58\u4E00\u4E0B\uFF0C\u4E0B\u4E00\u9875\u62FC\u63A5\u5230\u4E0A\u4E00\u9875\u5185\u5BB9\u540E\u9762\uFF0C\u8FD9\u6837\u53EF\u4EE5\u4E0A\u4E0B\u7FFB\u3002",-1)),D=_(`<code data-v-524d7e28>
                    <span class="function" data-v-524d7e28>mounted</span>(){
                    window.addEventListener(&#39;scroll&#39;, <span class="keyword" data-v-524d7e28>this</span>.handleScroll,true) // \u76D1\u542C\u9875\u9762\u6EDA\u52A8*/
                    },
                    methods:{
                        <span class="function" data-v-524d7e28>handleScroll</span> () {
                        //\u53D8\u91CFscrollTop\u662F\u6EDA\u52A8\u6761\u6EDA\u52A8\u65F6\uFF0C\u8DDD\u79BB\u9876\u90E8\u7684\u8DDD\u79BB
                        <span class="keyword" data-v-524d7e28>let</span> scrollTop = document.documentElement.scrollTop||document.body.scrollTop;
                        //\u53D8\u91CFwindowHeight\u662F\u53EF\u89C6\u533A\u7684\u9AD8\u5EA6
                        <span class="keyword" data-v-524d7e28>let</span> windowHeight = document.documentElement.clientHeight || document.body.clientHeight;
                        //\u53D8\u91CFscrollHeight\u662F\u6EDA\u52A8\u6761\u7684\u603B\u9AD8\u5EA6
                        <span class="keyword" data-v-524d7e28>let</span> scrollHeight = document.documentElement.scrollHeight||document.body.scrollHeight;
                        <span class="keyword" data-v-524d7e28>let</span> dataArr = []
                        //\u6EDA\u52A8\u6761\u5230\u5E95\u90E8\u7684\u6761\u4EF6
                        if(scrollTop + windowHeight === scrollHeight){
                            dataArr = <span class="keyword" data-v-524d7e28>this</span>.giftList //\u628A\u4E0A\u4E00\u9875\u7684\u6570\u636E\u8D4B\u7ED9dataArr
                            <span class="keyword" data-v-524d7e28>this</span>.pageNum = <span class="keyword" data-v-524d7e28>this</span>.pageNum + 1
                            <span class="keyword" data-v-524d7e28>this</span>.<span class="function" data-v-524d7e28>getList</span>()//\u8BF7\u6C42\u5230\u65B0\u4E00\u9875\u7684\u6570\u636E
                            <span class="keyword" data-v-524d7e28>this</span>.giftList = dataArr.<span class="function" data-v-524d7e28>concat</span>(<span class="keyword" data-v-524d7e28>this</span>.giftList)//\u6570\u636E\u62FC\u63A5
                        }
                        },
                    // \u83B7\u53D6\u6240\u6709\u5C55\u793A\u7684\u5151\u597D\u793C\u5217\u8868,\u670D\u52A1\u7AEF\u63A5\u53E3\u7528 rpc
                    <span class="function" data-v-524d7e28>getList</span>(){
                        <span class="keyword" data-v-524d7e28>let</span> param = {}
                        <span class="function" data-v-524d7e28>\u63A5\u53E3</span>(param,function(res){
                            <span class="keyword" data-v-524d7e28>let</span> res = <span class="keyword" data-v-524d7e28>this</span>.<span class="function" data-v-524d7e28>response</span>(res)
                            <span class="keyword" data-v-524d7e28>this</span>.giftList = res.list 
                        })
                    },
                    }
                </code>`,1),z=T({name:"BottomingOut"}),F=Object.assign(z,{setup(d){const k=L(),b=$(()=>k.bottomingOut),p=o(!1),u=o(!1),v=o(!1),h=o(null),y=o(null),w=o(null),H=o(null);return(l,e)=>{const m=E("el-button");return M(),S("div",{id:"one",ref_key:"oneRef",ref:H},[I,s("article",R,[V,s("div",{class:"contanier",onMouseover:e[1]||(e[1]=n=>p.value=!0),onMouseleave:e[2]||(e[2]=n=>p.value=!1)},[i(f(m,{icon:r(g),class:"copy",onClick:e[0]||(e[0]=n=>l.copy(h.value))},null,8,["icon"]),[[c,p.value]]),s("pre",{class:"pre",ref_key:"refClone",ref:h},[t("                "),j,t(`
            `)],512)],32),x,s("div",{class:"contanier",onMouseover:e[4]||(e[4]=n=>u.value=!0),onMouseleave:e[5]||(e[5]=n=>u.value=!1)},[i(f(m,{icon:r(g),class:"copy",onClick:e[3]||(e[3]=n=>l.copy(y.value))},null,8,["icon"]),[[c,u.value]]),s("pre",{class:"pre",ref_key:"refClone1",ref:y},[t("                "),U,t(`
            `)],512)],32),P,q,s("div",{class:"contanier",onMouseover:e[7]||(e[7]=n=>v.value=!0),onMouseleave:e[8]||(e[8]=n=>v.value=!1)},[i(f(m,{icon:r(g),class:"copy",onClick:e[6]||(e[6]=n=>l.copy(w.value))},null,8,["icon"]),[[c,v.value]]),s("pre",{class:"pre",ref_key:"refClone2",ref:w},[t("                "),D,t(`
            `)],512)],32)]),i(s("div",{href:"#one",class:"backToTop",onClick:e[9]||(e[9]=(...n)=>l.goTop&&l.goTop(...n))},"\u56DE\u5230\u9876\u90E8",512),[[c,r(b)]])],512)}}}),J=C(F,[["__scopeId","data-v-524d7e28"]]);export{J as default};
