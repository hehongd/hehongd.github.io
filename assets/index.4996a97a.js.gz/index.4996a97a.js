import{_ as m,d as f,u as b,c as y,r as c,a as k,b as g,e,f as d,v as p,g as w,h as r,i as u,k as x,l as C,p as T,q as I}from"./index.e74e1206.js";const n=o=>(T("data-v-d1f5f718"),o=o(),I(),o),O={id:"one"},S={class:"articleContanier"},D=n(()=>e("h1",null,"\u4E00\u3001label\u6807\u7B7E\u7684\u4F7F\u7528\u573A\u666F\u53CA\u610F\u4E49\u3002",-1)),N=n(()=>e("p",null,"\u4E00\u3001label\u6807\u7B7E\u7684\u4F5C\u7528\u662F\u4E3A\u9F20\u6807\u7528\u6237\u6539\u8FDB\u4E86\u53EF\u7528\u6027\uFF0C\u5F53\u7528\u6237\u70B9\u51FB\u3010\u3011\u6807\u7B7E\u4E2D\u7684\u6587\u672C\u65F6\uFF0C\u6D4F\u89C8\u5668\u5C31\u4F1A\u81EA\u52A8\u5C06\u7126\u70B9\u8F6C\u5230\u548C\u8BE5\u6807\u7B7E\u76F8\u5173\u8054\u7684\u63A7\u4EF6\u4E0A\u3002\u901A\u5E38\u662F\u5199\u5728\u8868\u5355\uFF08form\uFF09\u5185\u3002",-1)),B=n(()=>e("h1",null,"\u4E8C\u3001\u5C5E\u6027\u53CA\u7528\u6CD5\u3002",-1)),E=n(()=>e("h2",null,"1\u3001\u5C5E\u6027",-1)),L=n(()=>e("p",null,"label\u6709\u4E24\u4E2A\u5C5E\u6027for\u548Caccesskey\u3002",-1)),M=n(()=>e("p",null,"for\u529F\u80FD\uFF1A\u8868\u793A\u8FD9\u4E2ALable\u662F\u4E3A\u54EA\u4E2A\u63A7\u4EF6\u670D\u52A1\u7684\uFF0CLabel\u6807\u7B7E\u8981\u7ED1\u5B9A\u4E86for\u6307\u5B9AHTML\u5143\u7D20\u7684ID\u6216name\u5C5E\u6027\uFF0C\u4F60\u70B9\u51FB\u8FD9\u4E2A\u6807\u7B7E\u7684\u65F6\u5019\uFF0C\u6240\u7ED1\u5B9A\u7684\u5143\u7D20\u5C06\u83B7\u53D6\u7126\u70B9 \uFF0C\u70B9\u51FBlabel\u6240\u5305\u88F9\u5185\u5BB9\uFF0C\u81EA\u52A8\u6307\u5411for\u6307\u5B9A\u7684id\u6216name",-1)),U=n(()=>e("p",null,"accesskey\u5219\u5B9A\u4E49\u4E86\u8BBF\u95EE\u8FD9\u4E2A\u63A7\u4EF6\u7684\u70ED\u952E( \u6240\u8BBE\u7F6E\u7684\u5FEB\u6377\u952E\u4E0D\u80FD\u4E0E\u6D4F\u89C8\u5668\u7684\u5FEB\u6377\u952E\u51B2\u7A81\uFF0C\u5426\u5219\u5C06\u4F18\u5148\u6FC0\u6D3B\u6D4F\u89C8\u5668\u7684\u5FEB\u6377\u952E)",-1)),V=n(()=>e("h2",null,"2\u3001\u7528\u6CD5",-1)),$=n(()=>e("code",null,`
                        <!DOCTYPE html>
                            <html> lang="en">
                            <head>
                                <meta charset="UTF-8" />
                                <meta http-equiv="X-UA-Compatible" content="IE=edge" />
                                <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                                <title>Document</title>
                            </head>
                            <body>
                                <h1>label\u6807\u7B7E</h1>
                                <h3>\u4E00\u3001for\u7684\u7528\u6CD5</h3>
                                <h4>\u4E0D\u4F7F\u7528label\u7684\u6548\u679C</h4>
                                <div>
                                <span>\u6027\u522B</span>
                                <input type="radio" name="sex" value="man" />\u7537
                                <input type="radio" name="sex" value="woman" />\u5973
                                </div>
                                <hr />
                                <h4>\u4F7F\u7528label\u7684\u6548\u679C</h4>
                                <div>
                                <span>\u6027\u522B</span>
                                <!-- \u4EE5\u4E0B\u4E24\u79CD\u5199\u6CD5\u6548\u679C\u4E00\u81F4 -->
                                <!-- \u4F7F\u7528label\u76F4\u63A5\u5305\u88F9\u76EE\u6807\u6807\u7B7E\uFF0C\u9ED8\u8BA4for\u81EA\u52A8\u7ED1\u5B9A\u8BE5\u5143\u7D20 -->
                                <label><input type="radio" name="sex" value="man" />\u7537</label>
                                <!-- \u901A\u8FC7for\u5173\u8054\u76EE\u6807\u5143\u7D20id -->
                                <input type="radio" name="sex" value="woman" id="w" /><label for="w"
                                    >\u5973</label
                                >
                                </div>
                                <hr />
                                <h3>\u4E8C\u3001accesskey\u7684\u7528\u6CD5</h3>
                                <div>
                                    <!-- \u4F53\u9A8C\u65F6\u9700\u8981\u4F7F\u7528alt\u52A0accesskey\u6307\u5B9A\u7684\u952E\u624D\u53EF\u4EE5\u751F\u6548 -->
                                <label accesskey="N">\u8EAB\u9AD8\uFF1A<input type="text" /></label>
                                <label for="W" accesskey="O">\u4F53\u91CD\uFF1A</label><input type="text" id="W" />
                                </div>
                            </body>
                        </html>
                    `,-1)),q=n(()=>e("p",null,"\u5982\u56FE",-1)),W=n(()=>e("div",{class:"contanier"},[e("div",{class:"imgs"})],-1)),j=f({name:"htmlTag"}),A=Object.assign(j,{setup(o){const _=b(),h=y(()=>_.bottomingOut),a=c(!1),i=c(null);return(l,t)=>{const v=k("el-button");return x(),g("div",O,[e("article",S,[D,N,B,E,L,M,U,V,e("div",{class:"contanier",onMouseover:t[1]||(t[1]=s=>a.value=!0),onMouseleave:t[2]||(t[2]=s=>a.value=!1)},[d(w(v,{icon:r(C),class:"copy copyClass",onClick:t[0]||(t[0]=s=>l.copy(i.value))},null,8,["icon"]),[[p,a.value]]),e("pre",{class:"pre",ref_key:"refClone",ref:i},[u("                    "),$,u(`
                `)],512)],32),q,W]),d(e("div",{href:"#one",class:"backToTop",onClick:t[3]||(t[3]=(...s)=>l.goTop&&l.goTop(...s))},"\u56DE\u5230\u9876\u90E8",512),[[p,r(h)]])])}}}),H=m(A,[["__scopeId","data-v-d1f5f718"]]);export{H as default};
